# TODO - Gerador de Sensibilidade Free Fire

## Funcionalidades Principais

- [x] Design visual moderno com tema escuro inspirado em Free Fire
- [x] Página inicial com gerador de sensibilidade interativo
- [x] Formulário com sliders para ajustar cada tipo de sensibilidade (Geral, Ponto Vermelho, Mira 2x, Mira 4x, Mira AWM, Olhadinha)
- [x] Presets de sensibilidade (Iniciante, Balanceado, Agressivo, Pro Player)
- [x] Visualização em tempo real dos valores ajustados
- [x] Botão para copiar configurações
- [x] Seção educativa explicando cada tipo de sensibilidade
- [x] Design responsivo para mobile e desktop
- [x] Animações e micro-interações
